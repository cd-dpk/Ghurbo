package email;

public class StringManager {
}
