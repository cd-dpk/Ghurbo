import email.EmailExtractor;


public class HelloWorld {

	static String inputFileString="D://Ghurbo//Ghurbo//src//res//email_input.txt", outputFileString="src//res//email_output.txt";
	public static void main(String[] args) {
		new EmailExtractor().extractEmailFromInputFile(inputFileString, outputFileString);
		
	}
}
